import { AppointmentType } from "@shared/schema";

export interface AppointmentTypeInfo {
  id: AppointmentType;
  label: string;
  color: string;
  bgColor: string;
  borderColor: string;
}

export const appointmentTypes: AppointmentTypeInfo[] = [
  {
    id: "vet",
    label: "Vet",
    color: "text-green-800",
    bgColor: "bg-green-100",
    borderColor: "border-l-green-500",
  },
  {
    id: "grooming",
    label: "Grooming",
    color: "text-orange-800",
    bgColor: "bg-orange-100",
    borderColor: "border-l-orange-500",
  },
  {
    id: "walk",
    label: "Walk",
    color: "text-blue-800",
    bgColor: "bg-blue-100",
    borderColor: "border-l-blue-500",
  },
  {
    id: "training",
    label: "Training",
    color: "text-purple-800",
    bgColor: "bg-purple-100",
    borderColor: "border-l-purple-500",
  },
  {
    id: "other",
    label: "Other",
    color: "text-gray-800",
    bgColor: "bg-gray-100",
    borderColor: "border-l-gray-500",
  },
];

export const getAppointmentTypeInfo = (type: AppointmentType): AppointmentTypeInfo => {
  return appointmentTypes.find((t) => t.id === type) || appointmentTypes[4]; // Default to "other" if not found
};

export const getAppointmentCountsByType = (appointments: any[]): Record<string, number> => {
  const counts: Record<string, number> = {
    all: appointments.length,
  };
  
  appointmentTypes.forEach((type) => {
    counts[type.id] = appointments.filter((a) => a.type === type.id).length;
  });
  
  return counts;
};
