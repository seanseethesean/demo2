import { useEffect, useState } from 'react';
import { format } from 'date-fns';
import { Calendar as CalendarIcon, ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useQuery } from '@tanstack/react-query';
import Calendar from '@/components/Calendar';
import UpcomingAppointments from '@/components/UpcomingAppointments';
import MyDogs from '@/components/MyDogs';
import { getAppointmentCountsByType } from '@/utils/appointmentTypes';
import { appointmentTypes } from '@/utils/appointmentTypes';
import { Appointment } from '@shared/schema';

type CalendarView = 'month' | 'week' | 'day';

export default function Home() {
  const [date, setDate] = useState(new Date());
  const [view, setView] = useState<CalendarView>('month');
  const [selectedType, setSelectedType] = useState<string | null>(null);

  const { data: appointments = [], isLoading: isLoadingAppointments } = useQuery({
    queryKey: ['/api/appointments'],
  });

  const { data: dogs = [], isLoading: isLoadingDogs } = useQuery({
    queryKey: ['/api/dogs'],
  });

  const filteredAppointments = selectedType 
    ? appointments.filter((appointment: Appointment) => appointment.type === selectedType)
    : appointments;

  const appointmentCounts = getAppointmentCountsByType(appointments);

  const handlePrevMonth = () => {
    const newDate = new Date(date);
    newDate.setMonth(date.getMonth() - 1);
    setDate(newDate);
  };

  const handleNextMonth = () => {
    const newDate = new Date(date);
    newDate.setMonth(date.getMonth() + 1);
    setDate(newDate);
  };

  return (
    <div className="container mx-auto p-4">
      {/* Calendar Navigation */}
      <div className="mb-6 flex flex-col md:flex-row md:items-center md:justify-between">
        <div className="flex items-center space-x-1 mb-4 md:mb-0">
          <Button variant="ghost" size="icon" onClick={handlePrevMonth} aria-label="Previous Month">
            <ChevronLeft className="h-5 w-5" />
          </Button>
          <h2 className="text-2xl font-bold">{format(date, 'MMMM yyyy')}</h2>
          <Button variant="ghost" size="icon" onClick={handleNextMonth} aria-label="Next Month">
            <ChevronRight className="h-5 w-5" />
          </Button>
        </div>
        <div className="flex space-x-2 overflow-x-auto pb-2 md:pb-0">
          <Button 
            variant={view === 'month' ? 'default' : 'outline'} 
            onClick={() => setView('month')}
          >
            Month
          </Button>
          <Button 
            variant={view === 'week' ? 'default' : 'outline'} 
            onClick={() => setView('week')}
          >
            Week
          </Button>
          <Button 
            variant={view === 'day' ? 'default' : 'outline'} 
            onClick={() => setView('day')}
          >
            Day
          </Button>
        </div>
      </div>

      {/* Filter Section */}
      <div className="mb-6 p-4 bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="flex flex-wrap gap-2">
          <h3 className="text-sm font-medium w-full mb-2">Filter Appointments:</h3>
          <Button 
            onClick={() => setSelectedType(null)}
            className={`flex items-center rounded-full ${selectedType === null ? 'bg-primary text-white' : 'bg-white text-gray-700 border border-gray-300'}`}
            variant={selectedType === null ? 'default' : 'outline'}
            size="sm"
          >
            <span className="mr-1">All</span>
            <span className={`${selectedType === null ? 'bg-white text-primary' : 'bg-gray-100 text-gray-700'} rounded-full h-5 w-5 flex items-center justify-center`}>
              {appointmentCounts.all}
            </span>
          </Button>
          
          {appointmentTypes.map((type) => (
            <Button
              key={type.id}
              onClick={() => setSelectedType(type.id)}
              className={`flex items-center rounded-full ${selectedType === type.id ? 'bg-primary text-white' : 'bg-white text-gray-700 border border-gray-300'}`}
              variant={selectedType === type.id ? 'default' : 'outline'}
              size="sm"
            >
              <span className={`h-2 w-2 rounded-full ${type.bgColor.replace('bg-', 'bg-')} mr-1`}></span>
              <span className="mr-1">{type.label}</span>
              <span className={`${selectedType === type.id ? 'bg-white text-primary' : 'bg-gray-100 text-gray-700'} rounded-full h-5 w-5 flex items-center justify-center`}>
                {appointmentCounts[type.id] || 0}
              </span>
            </Button>
          ))}
        </div>
      </div>

      {/* Calendar */}
      <Calendar 
        date={date} 
        appointments={filteredAppointments} 
        view={view} 
        isLoading={isLoadingAppointments}
      />

      {/* Upcoming Appointments */}
      <UpcomingAppointments 
        appointments={filteredAppointments} 
        dogs={dogs} 
        isLoading={isLoadingAppointments}
      />

      {/* My Dogs */}
      <MyDogs dogs={dogs} isLoading={isLoadingDogs} />
    </div>
  );
}
