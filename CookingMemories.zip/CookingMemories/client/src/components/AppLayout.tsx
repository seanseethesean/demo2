import { ReactNode } from 'react';
import Header from './Header';

interface AppLayoutProps {
  children: ReactNode;
}

export default function AppLayout({ children }: AppLayoutProps) {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow">
        {children}
      </main>
      
      <footer className="bg-white border-t border-gray-200 mt-auto">
        <div className="container mx-auto px-4 py-4">
          <div className="flex flex-col md:flex-row md:justify-between md:items-center">
            <div className="text-center md:text-left mb-4 md:mb-0">
              <p className="text-sm text-gray-500">&copy; {new Date().getFullYear()} DoggyDates. All rights reserved.</p>
            </div>
            <div className="flex justify-center md:justify-end space-x-4">
              <a href="#" className="text-gray-500 hover:text-primary text-sm">Help & Support</a>
              <a href="#" className="text-gray-500 hover:text-primary text-sm">Privacy Policy</a>
              <a href="#" className="text-gray-500 hover:text-primary text-sm">Terms of Service</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
