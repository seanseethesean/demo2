import { format, parseISO, addDays, isBefore } from 'date-fns';
import { Pencil, Trash2, MapPin, Info } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import { useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { queryClient } from '@/lib/queryClient';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Dog, Appointment } from '@shared/schema';
import { getAppointmentTypeInfo } from '@/utils/appointmentTypes';
import AppointmentForm from './AppointmentForm';

interface UpcomingAppointmentsProps {
  appointments: Appointment[];
  dogs: Dog[];
  isLoading: boolean;
}

const UpcomingAppointments = ({ appointments, dogs, isLoading }: UpcomingAppointmentsProps) => {
  const [editingAppointment, setEditingAppointment] = useState<Appointment | null>(null);
  const { toast } = useToast();

  const deleteAppointmentMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/appointments/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/appointments'] });
      toast({
        title: "Appointment deleted",
        description: "The appointment has been successfully deleted.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete appointment: ${error}`,
        variant: "destructive",
      });
    }
  });

  const handleDelete = (id: number) => {
    if (window.confirm("Are you sure you want to delete this appointment?")) {
      deleteAppointmentMutation.mutate(id);
    }
  };

  const getDogNames = (dogIds: string[]): string => {
    return dogIds
      .map(id => {
        const dog = dogs.find(d => d.id === parseInt(id));
        return dog ? dog.name : '';
      })
      .filter(Boolean)
      .join(', ');
  };

  // Filter to show only upcoming appointments (today and future)
  const upcomingAppointments = appointments
    .filter(appointment => {
      const appointmentDate = parseISO(`${appointment.date}T${appointment.time}`);
      return !isBefore(appointmentDate, new Date()) || isBefore(appointmentDate, addDays(new Date(), 1));
    })
    .sort((a, b) => {
      const dateA = parseISO(`${a.date}T${a.time}`);
      const dateB = parseISO(`${b.date}T${b.time}`);
      return dateA.getTime() - dateB.getTime();
    })
    .slice(0, 6); // Limit to 6 upcoming appointments

  return (
    <>
      <div className="mt-8">
        <h2 className="text-xl font-bold mb-4">Upcoming Appointments</h2>
        
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1, 2, 3].map((_, i) => (
              <Card key={i} className="border border-l-4 border-l-gray-300">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <Skeleton className="h-5 w-36 mb-2" />
                      <Skeleton className="h-4 w-24" />
                    </div>
                  </div>
                  <Skeleton className="h-4 w-48 mb-2" />
                  <Skeleton className="h-32 w-full mb-2" />
                  <Skeleton className="h-4 w-full" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : upcomingAppointments.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {upcomingAppointments.map((appointment) => {
              const typeInfo = getAppointmentTypeInfo(appointment.type as any);
              const formattedDate = format(parseISO(`${appointment.date}T${appointment.time}`), 'EEEE, MMMM d');
              const formattedTime = format(parseISO(`${appointment.date}T${appointment.time}`), 'h:mm a');
              
              return (
                <Card 
                  key={appointment.id} 
                  className={`bg-white rounded-lg shadow-sm border ${typeInfo.borderColor} p-4 hover:shadow-md transition cursor-pointer`}
                >
                  <CardContent className="p-0">
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <h3 className="font-semibold">{appointment.title}</h3>
                        <p className="text-gray-500 text-sm">
                          {formattedDate} • {formattedTime}
                        </p>
                      </div>
                      <div className="flex">
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="text-gray-400 hover:text-primary h-8 w-8"
                          onClick={() => setEditingAppointment(appointment)}
                        >
                          <Pencil className="h-4 w-4" />
                          <span className="sr-only">Edit</span>
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="text-gray-400 hover:text-red-500 h-8 w-8"
                          onClick={() => handleDelete(appointment.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                          <span className="sr-only">Delete</span>
                        </Button>
                      </div>
                    </div>
                    <div className="flex items-center text-sm mb-2">
                      <MapPin className="h-4 w-4 mr-1 text-gray-500" />
                      <span className="text-gray-600">{appointment.location}</span>
                    </div>
                    {appointment.imageUrl && (
                      <img 
                        src={appointment.imageUrl} 
                        alt={appointment.title} 
                        className="w-full h-32 object-cover rounded mb-2"
                      />
                    )}
                    {appointment.notes && (
                      <div className="flex items-start">
                        <Info className="h-5 w-5 mr-1 text-gray-500 flex-shrink-0 mt-0.5" />
                        <p className="text-sm text-gray-600">{appointment.notes}</p>
                      </div>
                    )}
                    {appointment.dogIds && appointment.dogIds.length > 0 && (
                      <div className="mt-2 text-sm text-gray-600">
                        <span className="font-medium">Dogs:</span> {getDogNames(appointment.dogIds)}
                      </div>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        ) : (
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 text-center">
            <p className="text-gray-500">No upcoming appointments. Create one using the "New Appointment" button.</p>
          </div>
        )}
      </div>

      {editingAppointment && (
        <AppointmentForm
          isOpen={true}
          onClose={() => setEditingAppointment(null)}
          appointment={editingAppointment}
        />
      )}
    </>
  );
};

export default UpcomingAppointments;
