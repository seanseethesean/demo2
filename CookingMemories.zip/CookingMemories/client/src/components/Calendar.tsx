import { useState, useEffect } from 'react';
import { format, startOfMonth, endOfMonth, startOfWeek, endOfWeek, addDays, isSameMonth, isSameDay, parseISO } from 'date-fns';
import { Skeleton } from '@/components/ui/skeleton';
import { Appointment } from '@shared/schema';
import { getAppointmentTypeInfo } from '@/utils/appointmentTypes';

interface CalendarProps {
  date: Date;
  appointments: Appointment[];
  view: 'month' | 'week' | 'day';
  isLoading: boolean;
}

const Calendar = ({ date, appointments, view, isLoading }: CalendarProps) => {
  const [calendarDays, setCalendarDays] = useState<Date[]>([]);
  
  useEffect(() => {
    const days: Date[] = [];
    let startDate;
    let endDate;
    
    if (view === 'month') {
      // For a month view, start from the first day of the month's week
      startDate = startOfWeek(startOfMonth(date));
      // End on the last day of the month's week
      endDate = endOfWeek(endOfMonth(date));
    } else if (view === 'week') {
      // For a week view, just show the current week
      startDate = startOfWeek(date);
      endDate = endOfWeek(date);
    } else { // day view
      // For a day view, just show a single day
      startDate = date;
      endDate = date;
    }
    
    let day = startDate;
    while (day <= endDate) {
      days.push(day);
      day = addDays(day, 1);
    }
    
    setCalendarDays(days);
  }, [date, view]);

  if (isLoading) {
    return (
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
        <div className="grid grid-cols-7 text-center border-b border-gray-200 bg-gray-50">
          {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day, i) => (
            <div key={i} className="py-2 font-medium text-sm text-gray-700">{day}</div>
          ))}
        </div>
        <div className="grid grid-cols-7 text-sm">
          {Array.from({ length: 35 }).map((_, i) => (
            <div key={i} className="min-h-[100px] md:min-h-[120px] p-1 border-b border-r border-gray-200">
              <Skeleton className="h-5 w-5 ml-auto mb-2" />
              <Skeleton className="h-4 w-full mb-1" />
              <Skeleton className="h-4 w-3/4 mb-1" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  const getAppointmentsForDay = (day: Date) => {
    return appointments.filter(appointment => {
      const appointmentDate = parseISO(`${appointment.date}T${appointment.time}`);
      return isSameDay(appointmentDate, day);
    });
  };

  const getDayClasses = (day: Date) => {
    let classes = "min-h-[100px] md:min-h-[120px] p-1 border-b border-r border-gray-200";
    
    if (!isSameMonth(day, date)) {
      classes += " text-gray-400";
    }
    
    if (isSameDay(day, new Date())) {
      classes += " bg-indigo-50";
    }
    
    return classes;
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
      {/* Calendar Header */}
      <div className="grid grid-cols-7 text-center border-b border-gray-200 bg-gray-50">
        {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day, i) => (
          <div key={i} className="py-2 font-medium text-sm text-gray-700">{day}</div>
        ))}
      </div>
      
      {/* Calendar Body */}
      <div className="grid grid-cols-7 text-sm paw-print-bg">
        {calendarDays.map((day, idx) => (
          <div key={idx} className={getDayClasses(day)}>
            <div className={`text-right p-1 ${isSameDay(day, new Date()) ? 'font-bold text-primary' : ''}`}>
              {format(day, 'd')}
            </div>
            
            {getAppointmentsForDay(day).map((appointment, appIdx) => {
              const typeInfo = getAppointmentTypeInfo(appointment.type as any);
              return (
                <div 
                  key={appIdx}
                  className={`px-1 py-0.5 mb-1 text-xs ${typeInfo.bgColor} ${typeInfo.color} rounded truncate`}
                  title={appointment.title}
                >
                  {appointment.title} - {format(parseISO(`${appointment.date}T${appointment.time}`), 'h:mma')}
                </div>
              );
            })}
          </div>
        ))}
      </div>
    </div>
  );
};

export default Calendar;
