import { useState } from 'react';
import { Plus, Calendar, Pencil, Trash2 } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { useMutation } from '@tanstack/react-query';
import { queryClient } from '@/lib/queryClient';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Dog, InsertDog, extendedInsertDogSchema } from '@shared/schema';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';

interface MyDogsProps {
  dogs: Dog[];
  isLoading: boolean;
}

const dogImages = [
  "https://images.unsplash.com/photo-1552053831-71594a27632d?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=500",
  "https://images.unsplash.com/photo-1535930891776-0c2dfb7fda1a?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=500",
  "https://images.unsplash.com/photo-1583511655826-05700442b31b?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=500",
  "https://images.unsplash.com/photo-1560743173-567a3b5658b1?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=500",
  "https://images.unsplash.com/photo-1548199973-03cce0bbc87b?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=500",
  "https://images.unsplash.com/photo-1587300003388-59208cc962cb?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=500",
];

const MyDogs = ({ dogs, isLoading }: MyDogsProps) => {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingDog, setEditingDog] = useState<Dog | null>(null);
  const { toast } = useToast();

  const form = useForm<z.infer<typeof extendedInsertDogSchema>>({
    resolver: zodResolver(extendedInsertDogSchema),
    defaultValues: {
      name: '',
      breed: '',
      age: 0,
      birthdate: '',
      isVaccinated: false,
      isMicrochipped: false,
      needsGrooming: false,
      imageUrl: dogImages[Math.floor(Math.random() * dogImages.length)],
    },
  });

  const createDogMutation = useMutation({
    mutationFn: async (dog: InsertDog) => {
      const response = await apiRequest('POST', '/api/dogs', dog);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/dogs'] });
      setIsDialogOpen(false);
      form.reset();
      toast({
        title: "Success",
        description: "Dog profile created successfully!",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to create dog profile: ${error}`,
        variant: "destructive",
      });
    }
  });

  const updateDogMutation = useMutation({
    mutationFn: async ({ id, dog }: { id: number; dog: Partial<InsertDog> }) => {
      const response = await apiRequest('PUT', `/api/dogs/${id}`, dog);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/dogs'] });
      setIsDialogOpen(false);
      setEditingDog(null);
      form.reset();
      toast({
        title: "Success",
        description: "Dog profile updated successfully!",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update dog profile: ${error}`,
        variant: "destructive",
      });
    }
  });

  const deleteDogMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/dogs/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/dogs'] });
      toast({
        title: "Success",
        description: "Dog profile deleted successfully!",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete dog profile: ${error}`,
        variant: "destructive",
      });
    }
  });

  const handleDelete = (dog: Dog) => {
    if (window.confirm(`Are you sure you want to delete ${dog.name}'s profile?`)) {
      deleteDogMutation.mutate(dog.id);
    }
  };

  const onSubmit = (data: z.infer<typeof extendedInsertDogSchema>) => {
    if (editingDog) {
      updateDogMutation.mutate({ id: editingDog.id, dog: data });
    } else {
      createDogMutation.mutate(data);
    }
  };

  const openEditDialog = (dog: Dog) => {
    setEditingDog(dog);
    form.reset({
      name: dog.name,
      breed: dog.breed,
      age: dog.age,
      birthdate: dog.birthdate,
      isVaccinated: dog.isVaccinated,
      isMicrochipped: dog.isMicrochipped,
      needsGrooming: dog.needsGrooming,
      imageUrl: dog.imageUrl,
    });
    setIsDialogOpen(true);
  };

  const openNewDialog = () => {
    setEditingDog(null);
    form.reset({
      name: '',
      breed: '',
      age: 0,
      birthdate: '',
      isVaccinated: false,
      isMicrochipped: false,
      needsGrooming: false,
      imageUrl: dogImages[Math.floor(Math.random() * dogImages.length)],
    });
    setIsDialogOpen(true);
  };

  return (
    <>
      <div className="mt-8 mb-8">
        <h2 className="text-xl font-bold mb-4">My Dogs</h2>
        
        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[1, 2, 3].map((_, i) => (
              <Card key={i} className="overflow-hidden">
                <Skeleton className="h-40 w-full" />
                <CardContent className="p-4">
                  <Skeleton className="h-6 w-24 mb-1" />
                  <Skeleton className="h-4 w-32 mb-2" />
                  <Skeleton className="h-4 w-20 mb-2" />
                  <Skeleton className="h-6 w-full" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {dogs.map((dog) => (
              <Card key={dog.id} className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden hover:shadow-md transition">
                <div className="relative">
                  <img 
                    src={dog.imageUrl} 
                    alt={`${dog.name} - ${dog.breed}`} 
                    className="w-full h-40 object-cover"
                  />
                  <div className="absolute top-2 right-2 flex space-x-1">
                    <Button
                      variant="secondary"
                      size="icon"
                      className="h-8 w-8 rounded-full bg-white opacity-80 hover:opacity-100"
                      onClick={() => openEditDialog(dog)}
                    >
                      <Pencil className="h-4 w-4" />
                      <span className="sr-only">Edit</span>
                    </Button>
                    <Button
                      variant="secondary"
                      size="icon"
                      className="h-8 w-8 rounded-full bg-white opacity-80 hover:opacity-100"
                      onClick={() => handleDelete(dog)}
                    >
                      <Trash2 className="h-4 w-4" />
                      <span className="sr-only">Delete</span>
                    </Button>
                  </div>
                </div>
                <CardContent className="p-4">
                  <h3 className="font-semibold text-lg">{dog.name}</h3>
                  <p className="text-gray-500 text-sm">{dog.breed}</p>
                  <div className="flex items-center mt-2 text-sm text-gray-600">
                    <Calendar className="h-4 w-4 mr-1 text-gray-500" />
                    <span>{dog.age} {dog.age === 1 ? 'year' : 'years'} old</span>
                  </div>
                  <div className="mt-3 flex flex-wrap gap-1">
                    {dog.isVaccinated && (
                      <span className="bg-primary bg-opacity-10 text-primary text-xs px-2 py-1 rounded-full">Vaccinated</span>
                    )}
                    {dog.isMicrochipped && (
                      <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full">Microchipped</span>
                    )}
                    {dog.needsGrooming && (
                      <span className="bg-orange-100 text-orange-800 text-xs px-2 py-1 rounded-full">Needs Grooming</span>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
            
            {/* Add New Dog Button */}
            <div 
              className="bg-white rounded-lg border border-dashed border-gray-300 flex items-center justify-center hover:border-primary hover:bg-gray-50 transition cursor-pointer min-h-[230px]"
              onClick={openNewDialog}
            >
              <div className="text-center p-4">
                <div className="mx-auto bg-gray-100 rounded-full h-12 w-12 flex items-center justify-center mb-2">
                  <Plus className="h-6 w-6 text-gray-500" />
                </div>
                <span className="text-gray-600 font-medium">Add New Dog</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* New/Edit Dog Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>{editingDog ? `Edit ${editingDog.name}'s Profile` : 'Add New Dog'}</DialogTitle>
            <DialogDescription>
              {editingDog 
                ? 'Update your dog\'s information below.' 
                : 'Fill out the details to add a new dog to your profile.'}
            </DialogDescription>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Dog's name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="breed"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Breed</FormLabel>
                    <FormControl>
                      <Input placeholder="Dog's breed" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="age"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Age (years)</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          min="0" 
                          {...field} 
                          onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="birthdate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Birthdate (optional)</FormLabel>
                      <FormControl>
                        <Input type="date" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="space-y-2">
                <FormField
                  control={form.control}
                  name="isVaccinated"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                      <FormControl>
                        <Checkbox 
                          checked={field.value} 
                          onCheckedChange={field.onChange} 
                        />
                      </FormControl>
                      <FormLabel className="font-normal cursor-pointer">Vaccinated</FormLabel>
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="isMicrochipped"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                      <FormControl>
                        <Checkbox 
                          checked={field.value} 
                          onCheckedChange={field.onChange} 
                        />
                      </FormControl>
                      <FormLabel className="font-normal cursor-pointer">Microchipped</FormLabel>
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="needsGrooming"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                      <FormControl>
                        <Checkbox 
                          checked={field.value} 
                          onCheckedChange={field.onChange} 
                        />
                      </FormControl>
                      <FormLabel className="font-normal cursor-pointer">Needs Grooming</FormLabel>
                    </FormItem>
                  )}
                />
              </div>
              
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={createDogMutation.isPending || updateDogMutation.isPending}>
                  {createDogMutation.isPending || updateDogMutation.isPending ? 'Saving...' : 'Save'}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default MyDogs;
