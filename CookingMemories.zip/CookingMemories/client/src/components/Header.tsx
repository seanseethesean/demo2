import { useState } from 'react';
import { Link } from 'wouter';
import { PlusIcon, SunIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import AppointmentForm from './AppointmentForm';

export default function Header() {
  const [isFormOpen, setIsFormOpen] = useState(false);

  return (
    <>
      <header className="bg-white border-b border-gray-200 shadow-sm">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Link href="/">
              <a className="flex items-center space-x-2">
                <SunIcon className="h-8 w-8 text-primary" />
                <h1 className="text-xl font-bold">DoggyDates</h1>
              </a>
            </Link>
          </div>
          <div className="flex items-center">
            <Button onClick={() => setIsFormOpen(true)} className="flex items-center">
              <PlusIcon className="h-5 w-5 mr-1" />
              New Appointment
            </Button>
          </div>
        </div>
      </header>

      <AppointmentForm 
        isOpen={isFormOpen} 
        onClose={() => setIsFormOpen(false)} 
      />
    </>
  );
}
