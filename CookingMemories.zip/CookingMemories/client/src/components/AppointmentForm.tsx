import { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { queryClient } from '@/lib/queryClient';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { format, parseISO } from 'date-fns';
import { appointmentTypes } from '@/utils/appointmentTypes';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Dog, Appointment, extendedInsertAppointmentSchema } from '@shared/schema';

interface AppointmentFormProps {
  isOpen: boolean;
  onClose: () => void;
  appointment?: Appointment;
}

const appointmentImages = {
  vet: "https://images.unsplash.com/photo-1581888227599-779811939961?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
  grooming: "https://images.unsplash.com/photo-1516734212186-a967f81ad0d7?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
  walk: "https://images.unsplash.com/photo-1598133894008-61f7fdb8cc3a?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
  training: "https://images.unsplash.com/photo-1553322396-0c9cd410935e?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
  other: "https://images.unsplash.com/photo-1550220616-afaaae4f9681?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
};

const AppointmentForm = ({ isOpen, onClose, appointment }: AppointmentFormProps) => {
  const [selectedType, setSelectedType] = useState<string | undefined>(appointment?.type);
  const { toast } = useToast();

  const { data: dogs = [] } = useQuery({
    queryKey: ['/api/dogs'],
  });

  const form = useForm<z.infer<typeof extendedInsertAppointmentSchema>>({
    resolver: zodResolver(extendedInsertAppointmentSchema),
    defaultValues: {
      title: appointment?.title || '',
      date: appointment?.date || format(new Date(), 'yyyy-MM-dd'),
      time: appointment?.time || format(new Date(), 'HH:mm'),
      type: appointment?.type || 'vet',
      location: appointment?.location || '',
      notes: appointment?.notes || '',
      dogIds: appointment?.dogIds || [],
      reminderEnabled: appointment?.reminderEnabled || false,
      imageUrl: appointment?.imageUrl || appointmentImages.vet,
    },
  });

  useEffect(() => {
    if (appointment) {
      form.reset({
        title: appointment.title,
        date: appointment.date,
        time: appointment.time,
        type: appointment.type,
        location: appointment.location || '',
        notes: appointment.notes || '',
        dogIds: appointment.dogIds,
        reminderEnabled: appointment.reminderEnabled || false,
        imageUrl: appointment.imageUrl || appointmentImages[appointment.type as keyof typeof appointmentImages],
      });
      setSelectedType(appointment.type);
    }
  }, [appointment, form]);

  const createAppointmentMutation = useMutation({
    mutationFn: async (data: z.infer<typeof extendedInsertAppointmentSchema>) => {
      const response = await apiRequest('POST', '/api/appointments', data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/appointments'] });
      onClose();
      form.reset();
      toast({
        title: "Success",
        description: "Appointment created successfully!",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to create appointment: ${error}`,
        variant: "destructive",
      });
    }
  });

  const updateAppointmentMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: z.infer<typeof extendedInsertAppointmentSchema> }) => {
      const response = await apiRequest('PUT', `/api/appointments/${id}`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/appointments'] });
      onClose();
      form.reset();
      toast({
        title: "Success",
        description: "Appointment updated successfully!",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update appointment: ${error}`,
        variant: "destructive",
      });
    }
  });

  const onSubmit = (data: z.infer<typeof extendedInsertAppointmentSchema>) => {
    // Update the image URL based on the selected type
    const updatedData = {
      ...data,
      imageUrl: data.imageUrl || appointmentImages[data.type as keyof typeof appointmentImages],
    };

    if (appointment) {
      updateAppointmentMutation.mutate({ id: appointment.id, data: updatedData });
    } else {
      createAppointmentMutation.mutate(updatedData);
    }
  };

  const handleTypeChange = (value: string) => {
    setSelectedType(value);
    // Update the image URL when type changes
    form.setValue('imageUrl', appointmentImages[value as keyof typeof appointmentImages]);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>{appointment ? 'Edit Appointment' : 'New Appointment'}</DialogTitle>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Appointment Title</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g., Vet Visit, Grooming, etc." {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="date"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Date</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="time"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Time</FormLabel>
                    <FormControl>
                      <Input type="time" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <FormField
              control={form.control}
              name="type"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Appointment Type</FormLabel>
                  <Select 
                    onValueChange={(value) => {
                      field.onChange(value);
                      handleTypeChange(value);
                    }} 
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select Type" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {appointmentTypes.map((type) => (
                        <SelectItem key={type.id} value={type.id}>
                          <div className="flex items-center">
                            <span className={`h-2 w-2 rounded-full ${type.bgColor} mr-2`}></span>
                            {type.label}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="location"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Location</FormLabel>
                  <FormControl>
                    <Input placeholder="Location name or address" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="dogIds"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Select Dogs</FormLabel>
                  <div className="space-y-2">
                    {dogs.map((dog: Dog) => (
                      <div key={dog.id} className="flex items-center space-x-2">
                        <Checkbox 
                          checked={field.value.includes(dog.id.toString())}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              field.onChange([...field.value, dog.id.toString()]);
                            } else {
                              field.onChange(field.value.filter(id => id !== dog.id.toString()));
                            }
                          }}
                          id={`dog-${dog.id}`}
                        />
                        <label 
                          htmlFor={`dog-${dog.id}`}
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                        >
                          {dog.name} ({dog.breed})
                        </label>
                      </div>
                    ))}
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Notes</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Additional details..." 
                      className="resize-none" 
                      rows={3} 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="reminderEnabled"
              render={({ field }) => (
                <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                  <FormControl>
                    <Checkbox 
                      checked={field.value} 
                      onCheckedChange={field.onChange} 
                    />
                  </FormControl>
                  <FormLabel className="font-normal cursor-pointer">Set reminder notification</FormLabel>
                </FormItem>
              )}
            />
            
            <DialogFooter>
              <Button type="button" variant="outline" onClick={onClose}>
                Cancel
              </Button>
              <Button type="submit" disabled={createAppointmentMutation.isPending || updateAppointmentMutation.isPending}>
                {createAppointmentMutation.isPending || updateAppointmentMutation.isPending 
                  ? 'Saving...' 
                  : appointment ? 'Update Appointment' : 'Save Appointment'
                }
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
};

export default AppointmentForm;
