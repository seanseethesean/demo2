import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Dog schema
export const dogs = pgTable("dogs", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  breed: text("breed").notNull(),
  age: integer("age"),
  birthdate: text("birthdate"),
  isVaccinated: boolean("is_vaccinated").default(false),
  isMicrochipped: boolean("is_microchipped").default(false),
  needsGrooming: boolean("needs_grooming").default(false),
  imageUrl: text("image_url"),
});

export const insertDogSchema = createInsertSchema(dogs).omit({
  id: true,
});

// Appointment schema
export const appointments = pgTable("appointments", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  date: text("date").notNull(),
  time: text("time").notNull(),
  type: text("type").notNull(), // vet, grooming, walk, training, other
  location: text("location"),
  notes: text("notes"),
  dogIds: text("dog_ids").array(), // Array of dog IDs that this appointment is for
  reminderEnabled: boolean("reminder_enabled").default(false),
  imageUrl: text("image_url"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertAppointmentSchema = createInsertSchema(appointments).omit({
  id: true,
  createdAt: true,
});

// Define the appointment types for validation
export const appointmentTypeSchema = z.enum([
  "vet",
  "grooming",
  "walk", 
  "training",
  "other"
]);

// Define the extended schemas with validation
export const extendedInsertDogSchema = insertDogSchema.extend({
  name: z.string().min(1, "Name is required"),
  breed: z.string().min(1, "Breed is required"),
});

export const extendedInsertAppointmentSchema = insertAppointmentSchema.extend({
  title: z.string().min(1, "Title is required"),
  date: z.string().min(1, "Date is required"),
  time: z.string().min(1, "Time is required"),
  type: appointmentTypeSchema,
  dogIds: z.array(z.string()).min(1, "At least one dog must be selected"),
});

// Export the types
export type InsertDog = z.infer<typeof insertDogSchema>;
export type Dog = typeof dogs.$inferSelect;

export type InsertAppointment = z.infer<typeof insertAppointmentSchema>;
export type Appointment = typeof appointments.$inferSelect;
export type AppointmentType = z.infer<typeof appointmentTypeSchema>;
