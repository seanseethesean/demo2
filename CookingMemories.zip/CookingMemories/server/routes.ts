import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { 
  insertDogSchema, 
  insertAppointmentSchema, 
  extendedInsertDogSchema, 
  extendedInsertAppointmentSchema, 
  appointmentTypeSchema 
} from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // Dogs API endpoints
  app.get("/api/dogs", async (req, res) => {
    try {
      const dogs = await storage.getDogs();
      res.json(dogs);
    } catch (error) {
      res.status(500).json({ message: "Failed to get dogs", error: String(error) });
    }
  });

  app.get("/api/dogs/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid dog ID" });
      }

      const dog = await storage.getDog(id);
      if (!dog) {
        return res.status(404).json({ message: "Dog not found" });
      }

      res.json(dog);
    } catch (error) {
      res.status(500).json({ message: "Failed to get dog", error: String(error) });
    }
  });

  app.post("/api/dogs", async (req, res) => {
    try {
      const validatedData = extendedInsertDogSchema.parse(req.body);
      const dog = await storage.createDog(validatedData);
      res.status(201).json(dog);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: "Validation error", error: validationError.message });
      }
      res.status(500).json({ message: "Failed to create dog", error: String(error) });
    }
  });

  app.put("/api/dogs/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid dog ID" });
      }

      const validatedData = insertDogSchema.partial().parse(req.body);
      const dog = await storage.updateDog(id, validatedData);
      
      if (!dog) {
        return res.status(404).json({ message: "Dog not found" });
      }

      res.json(dog);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: "Validation error", error: validationError.message });
      }
      res.status(500).json({ message: "Failed to update dog", error: String(error) });
    }
  });

  app.delete("/api/dogs/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid dog ID" });
      }

      const success = await storage.deleteDog(id);
      if (!success) {
        return res.status(404).json({ message: "Dog not found" });
      }

      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete dog", error: String(error) });
    }
  });

  // Appointments API endpoints
  app.get("/api/appointments", async (req, res) => {
    try {
      const appointments = await storage.getAppointments();
      res.json(appointments);
    } catch (error) {
      res.status(500).json({ message: "Failed to get appointments", error: String(error) });
    }
  });

  app.get("/api/appointments/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid appointment ID" });
      }

      const appointment = await storage.getAppointment(id);
      if (!appointment) {
        return res.status(404).json({ message: "Appointment not found" });
      }

      res.json(appointment);
    } catch (error) {
      res.status(500).json({ message: "Failed to get appointment", error: String(error) });
    }
  });

  app.post("/api/appointments", async (req, res) => {
    try {
      const validatedData = extendedInsertAppointmentSchema.parse(req.body);
      const appointment = await storage.createAppointment(validatedData);
      res.status(201).json(appointment);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: "Validation error", error: validationError.message });
      }
      res.status(500).json({ message: "Failed to create appointment", error: String(error) });
    }
  });

  app.put("/api/appointments/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid appointment ID" });
      }

      const validatedData = insertAppointmentSchema.partial().parse(req.body);
      const appointment = await storage.updateAppointment(id, validatedData);
      
      if (!appointment) {
        return res.status(404).json({ message: "Appointment not found" });
      }

      res.json(appointment);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: "Validation error", error: validationError.message });
      }
      res.status(500).json({ message: "Failed to update appointment", error: String(error) });
    }
  });

  app.delete("/api/appointments/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid appointment ID" });
      }

      const success = await storage.deleteAppointment(id);
      if (!success) {
        return res.status(404).json({ message: "Appointment not found" });
      }

      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete appointment", error: String(error) });
    }
  });

  app.get("/api/appointments/type/:type", async (req, res) => {
    try {
      const type = req.params.type;
      
      try {
        // Validate the type parameter
        appointmentTypeSchema.parse(type);
      } catch (error) {
        return res.status(400).json({ message: "Invalid appointment type" });
      }
      
      const appointments = await storage.getAppointmentsByType(type);
      res.json(appointments);
    } catch (error) {
      res.status(500).json({ message: "Failed to get appointments by type", error: String(error) });
    }
  });

  app.get("/api/appointments/dog/:dogId", async (req, res) => {
    try {
      const dogId = parseInt(req.params.dogId);
      if (isNaN(dogId)) {
        return res.status(400).json({ message: "Invalid dog ID" });
      }

      const appointments = await storage.getAppointmentsByDogId(dogId);
      res.json(appointments);
    } catch (error) {
      res.status(500).json({ message: "Failed to get appointments by dog ID", error: String(error) });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
