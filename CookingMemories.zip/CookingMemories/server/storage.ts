import { dogs, appointments, type Dog, type InsertDog, type Appointment, type InsertAppointment } from "@shared/schema";

// interface for storage operations
export interface IStorage {
  // Dog operations
  getDogs(): Promise<Dog[]>;
  getDog(id: number): Promise<Dog | undefined>;
  createDog(dog: InsertDog): Promise<Dog>;
  updateDog(id: number, dog: Partial<InsertDog>): Promise<Dog | undefined>;
  deleteDog(id: number): Promise<boolean>;
  
  // Appointment operations
  getAppointments(): Promise<Appointment[]>;
  getAppointment(id: number): Promise<Appointment | undefined>;
  createAppointment(appointment: InsertAppointment): Promise<Appointment>;
  updateAppointment(id: number, appointment: Partial<InsertAppointment>): Promise<Appointment | undefined>;
  deleteAppointment(id: number): Promise<boolean>;
  getAppointmentsByType(type: string): Promise<Appointment[]>;
  getAppointmentsByDogId(dogId: number): Promise<Appointment[]>;
}

export class MemStorage implements IStorage {
  private dogs: Map<number, Dog>;
  private appointments: Map<number, Appointment>;
  private dogId: number;
  private appointmentId: number;

  constructor() {
    this.dogs = new Map();
    this.appointments = new Map();
    this.dogId = 1;
    this.appointmentId = 1;

    // Add some sample dogs
    this.createDog({
      name: "Max",
      breed: "Golden Retriever",
      age: 3,
      birthdate: "2020-05-15",
      isVaccinated: true,
      isMicrochipped: true,
      needsGrooming: false,
      imageUrl: "https://images.unsplash.com/photo-1552053831-71594a27632d?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=500"
    });

    this.createDog({
      name: "Bella",
      breed: "Poodle",
      age: 2,
      birthdate: "2021-08-10",
      isVaccinated: true,
      isMicrochipped: false,
      needsGrooming: true,
      imageUrl: "https://images.unsplash.com/photo-1535930891776-0c2dfb7fda1a?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=500"
    });

    // Add some sample appointments
    const currentYear = new Date().getFullYear();
    const currentMonth = new Date().getMonth() + 1;

    this.createAppointment({
      title: "Vet Visit - Vaccinations",
      date: `${currentYear}-${currentMonth.toString().padStart(2, '0')}-13`,
      time: "09:00",
      type: "vet",
      location: "PetCare Veterinary Clinic",
      notes: "Annual vaccinations and general checkup. Remember to bring vaccination records.",
      dogIds: ["1"],
      reminderEnabled: true,
      imageUrl: "https://images.unsplash.com/photo-1581888227599-779811939961?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
    });

    this.createAppointment({
      title: "Park Visit",
      date: `${currentYear}-${currentMonth.toString().padStart(2, '0')}-13`,
      time: "17:00",
      type: "walk",
      location: "Dogwood Park",
      notes: "Meet up with other dog owners. Bring tennis balls and water bowl.",
      dogIds: ["1", "2"],
      reminderEnabled: false,
      imageUrl: "https://images.unsplash.com/photo-1598133894008-61f7fdb8cc3a?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
    });

    this.createAppointment({
      title: "Grooming Appointment",
      date: `${currentYear}-${currentMonth.toString().padStart(2, '0')}-21`,
      time: "15:00",
      type: "grooming",
      location: "Pampered Paws Grooming",
      notes: "Full grooming package: bath, haircut, nail trimming, and ear cleaning.",
      dogIds: ["2"],
      reminderEnabled: true,
      imageUrl: "https://images.unsplash.com/photo-1516734212186-a967f81ad0d7?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
    });
  }

  // Dog operations
  async getDogs(): Promise<Dog[]> {
    return Array.from(this.dogs.values());
  }

  async getDog(id: number): Promise<Dog | undefined> {
    return this.dogs.get(id);
  }

  async createDog(dog: InsertDog): Promise<Dog> {
    const id = this.dogId++;
    const newDog: Dog = { ...dog, id };
    this.dogs.set(id, newDog);
    return newDog;
  }

  async updateDog(id: number, dog: Partial<InsertDog>): Promise<Dog | undefined> {
    const existingDog = this.dogs.get(id);
    if (!existingDog) return undefined;
    
    const updatedDog = { ...existingDog, ...dog };
    this.dogs.set(id, updatedDog);
    return updatedDog;
  }

  async deleteDog(id: number): Promise<boolean> {
    return this.dogs.delete(id);
  }

  // Appointment operations
  async getAppointments(): Promise<Appointment[]> {
    return Array.from(this.appointments.values());
  }

  async getAppointment(id: number): Promise<Appointment | undefined> {
    return this.appointments.get(id);
  }

  async createAppointment(appointment: InsertAppointment): Promise<Appointment> {
    const id = this.appointmentId++;
    const createdAt = new Date();
    const newAppointment: Appointment = { ...appointment, id, createdAt };
    this.appointments.set(id, newAppointment);
    return newAppointment;
  }

  async updateAppointment(id: number, appointment: Partial<InsertAppointment>): Promise<Appointment | undefined> {
    const existingAppointment = this.appointments.get(id);
    if (!existingAppointment) return undefined;
    
    const updatedAppointment = { ...existingAppointment, ...appointment };
    this.appointments.set(id, updatedAppointment);
    return updatedAppointment;
  }

  async deleteAppointment(id: number): Promise<boolean> {
    return this.appointments.delete(id);
  }

  async getAppointmentsByType(type: string): Promise<Appointment[]> {
    return Array.from(this.appointments.values()).filter(
      appointment => appointment.type === type
    );
  }

  async getAppointmentsByDogId(dogId: number): Promise<Appointment[]> {
    return Array.from(this.appointments.values()).filter(
      appointment => appointment.dogIds.includes(dogId.toString())
    );
  }
}

export const storage = new MemStorage();
